function x=CreateData1(m)


x1A =1 ;
x2A=1;
xA = [x1A+rand(m,1) x2A+rand(m,1)];


x1B = 4;
x2B = 2;
xB = [x1B+rand(m,1) x2B+rand(m,1)]

x1C=2;
x2C = 5
xB = [x1C+rand(m,1) x2C+rand(m,1)]

x = [xA xB xC]